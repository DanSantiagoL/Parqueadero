<!DOCTYPE html>
<html>

<head>
	<title>Compensar 2.0 - Agendar Citas</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			background-color: #f2f2f2;
			margin: 0;
			padding: 0;
		}

		header {
			background-color: #333;
			color: #fff;
			padding: 20px;
			text-align: center;
		}

		h1 {
			margin: 0;
		}

		nav {
			background-color: #333;
			color: #fff;
			padding: 10px;
		}

		nav ul {
			margin: 0;
			padding: 0;
			list-style-type: none;
			text-align: center;
		}

		nav ul li {
			display: inline-block;
			margin-right: 10px;
		}

		nav ul li a {
			color: #fff;
			text-decoration: none;
			padding: 5px 10px;
		}

		nav ul li a:hover {
			background-color: #555;
		}

		.container {
			max-width: 800px;
			margin: 0 auto;
			padding: 20px;
		}

		.welcome-message {
			text-align: center;
			font-size: 24px;
			margin-bottom: 20px;
		}

		form {
			background-color: #fff;
			padding: 20px;
			border-radius: 5px;
		}

		label {
			display: block;
			margin-bottom: 10px;
		}

		input[type="text"],
		input[type="email"],
		select {
			width: 100%;
			padding: 10px;
			border: 1px solid #ccc;
			border-radius: 3px;
			margin-bottom: 10px;
		}

		input[type="submit"] {
			background-color: #333;
			color: #fff;
			padding: 10px 20px;
			border: none;
			border-radius: 3px;
			cursor: pointer;
		}

		input[type="submit"]:hover {
			background-color: #555;
		}
	</style>
</head>

<body>
	<header>
		<h1>Llantas S.A - Parqueadero</h1>
		<nav>
			<ul>
				<li><a href="#">Inicio</a></li>
				<li><a href="about">Sobre Nosotros</a></li>
				<li><a href="/news/create">Registrar</a></li>
				<li><a href="../news">Consultar Vehiculo</a></li>
			</ul>
		</nav>
	</header>

	<div class="container">
		<div class="welcome-message">
			<p>Bienvenido/a a Llantas S.A</p>
			<p>¡Bienvenido al Llantas S.A!

Estamos encantados de recibirte en nuestro parqueadero. Nuestro objetivo es brindarte un servicio seguro y confiable para el estacionamiento de tu vehículo. Ya sea que estés aquí por un corto periodo o necesites un lugar de estacionamiento a largo plazo, estamos aquí para satisfacer tus necesidades.

En nuestro parqueadero, encontrarás un ambiente amigable y un equipo dispuesto a ayudarte en lo que necesites. Nuestras instalaciones están equipadas con medidas de seguridad de última generación para garantizar la protección de tu vehículo.

Explora nuestras amplias instalaciones y elige el lugar perfecto para estacionar tu coche. Contamos con espacios designados, accesibles y bien señalizados para una experiencia de estacionamiento sin complicaciones.

Además, te ofrecemos opciones flexibles de tarifas y planes de estacionamiento para adaptarnos a tus necesidades individuales. Nuestro objetivo es hacer tu experiencia de estacionamiento lo más conveniente y cómoda posible.

Gracias por elegir el Llantas S.A. Esperamos que tu estancia aquí sea agradable y que confíes en nosotros para todas tus necesidades de estacionamiento. Si tienes alguna pregunta o necesitas ayuda, no dudes en acercarte a nuestro amable equipo de atención al cliente.

¡Disfruta tu visita al Llantas S.A!</p>
		</div>
	</div>
</body>

</html>