<!doctype html>
<html>
<head>
    <title>Llantas S.A</title>
</head>
<body>

    <h1><?= esc($title) ?></h1>
    <img src="https://static.vecteezy.com/system/resources/previews/001/188/777/original/burn-out-tire-png.png" alt="Logo de la empresa" width="150px" style="float: right; margin: 10px">
  