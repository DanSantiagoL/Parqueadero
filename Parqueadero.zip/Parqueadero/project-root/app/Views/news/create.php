<!DOCTYPE html>
<html>

<head>
    <?= session()->getFlashdata('error') ?>
    <?= validation_list_errors() ?>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        h1 {
            margin: 0;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
        }

        nav ul {
            margin: 0;
            padding: 0;
            list-style-type: none;
            text-align: center;
        }

        nav ul li {
            display: inline-block;
            margin-right: 10px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            padding: 5px 10px;
        }

        nav ul li a:hover {
            background-color: #555;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .welcome-message {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }

        form {
            padding: 20px;
            border-radius: 5px;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="input"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>

<body>
    <header>
        <h1>Llantas S.A - Parqueadero</h1>
        <nav>
            <ul>
                <li><a href="../home">Inicio</a></li>
                <li><a href="../about">Sobre Nosotros</a></li>
                <li><a href="#">Registrar Vehiculo</a></li>
                <li><a href="/news">Consultar Vehiculo</a></li>
            </ul>
        </nav>
    </header>
    <center>

        <form action="/news/create" method="post" class="custom-form">
            <?= csrf_field() ?>

            <h3><label for="vehiculo">Ingrese el modelo y la placa del vehiculo que va a ingresar</label></h3>
            <input type="text" name="vehiculo" value="<?= set_value('vehiculo') ?>" required>
            <br>

            <h3><label for="conductor">Ingrese el nombre y apellido del conductor</label></h3>
            <input type="text" name="conductor" value="<?= set_value('conductor') ?>" required>
            <br>

            <h3><label for="tiempo_uso">Ingrese el tiempo en minutos que va a estar en el estacionamiento</label></h3>
            <input type="number" name="tiempo_uso" value="<?= set_value('tiempo_uso') ?>" required>
            <br>

            <h3><label for="total">Ingrese el total a pagar</label></h3>
            <input type="int" name="total" value="<?= set_value('total') ?>" required></textarea>
            <br><br>

            <input type="submit" name="submit" value="Registrar Vehiculo">
        </form>

    </center>

</body>

</html>