<h3>Hola <?= esc($news_item['conductor']) ?> tu coche es: <?= esc($news_item['vehiculo']) ?></h3>
<p><?= esc($news_item['tiempo_uso']) ?></p>
<p><?= esc($news_item['total']) ?></p>