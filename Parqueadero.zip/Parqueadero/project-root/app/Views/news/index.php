<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #f5f5f5;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #333;
      color: #fff;
      padding: 20px;
      text-align: center;
    }

    h1 {
      margin: 0;
    }

    nav {
      background-color: #333;
      color: #fff;
      padding: 10px;
    }

    nav ul {
      margin: 0;
      padding: 0;
      list-style-type: none;
      text-align: center;
    }

    nav ul li {
      display: inline-block;
      margin-right: 10px;
    }

    nav ul li a {
      color: #fff;
      text-decoration: none;
      padding: 5px 10px;
    }

    nav ul li a:hover {
      background-color: #555;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }

    .welcome-message {
      text-align: center;
      font-size: 24px;
      margin-bottom: 20px;
    }

    form {
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
    }

    label {
      display: block;
      margin-bottom: 10px;
    }

    input[type="input"],
    textarea,
    select {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
      margin-bottom: 10px;
    }

    input[type="submit"] {
      background-color: #333;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 3px;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #555;
    }
  </style>


<?php if (!empty($news) && is_array($news)): ?>

    <header>
		<h1>Llantas S.A - Parqueadero</h1>
		<nav>
			<ul>
				<li><a href="../home">Inicio</a></li>
				<li><a href="../about">Sobre Nosotros</a></li>
				<li><a href="/news/create">Registrar Vehiculo</a></li>
				<li><a href="#">Consultar Vehiculo</a></li>
			</ul>
		</nav>
	</header>

<table>
    <thead>
        <tr>
            <th>Conductor</th>
            <th>Vehículo</th>
            <th>Tiempo de uso</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($news as $news_item): ?>
        <tr>
            <td><?= esc($news_item['conductor']) ?></td>
            <td><?= esc($news_item['vehiculo']) ?></td>
            <td><?= esc($news_item['tiempo_uso']) ?> minutos</td>
            <td><?= esc($news_item['total']) ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php else: ?>

<h3>No News</h3>

<p>Unable to find any news for you.</p>

<?php endif; ?>