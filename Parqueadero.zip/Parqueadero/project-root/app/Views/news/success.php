<p>El vehiculo se registro correctamente.</p>
<a href="../news">volver</a><br>